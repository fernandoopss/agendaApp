from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timezone

from src.models.database import db, User, UserRole

users_bp = Blueprint('users', __name__)

@users_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        return jsonify({'user': user.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@users_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        
        # Campos que podem ser atualizados
        if 'name' in data:
            user.name = data['name'].strip()
        
        if 'phone' in data:
            user.phone = data['phone'].strip()
        
        if 'avatar_url' in data:
            user.avatar_url = data['avatar_url']
        
        user.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Perfil atualizado com sucesso',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@users_bp.route('/appointments', methods=['GET'])
@jwt_required()
def get_user_appointments():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        # Parâmetros de paginação
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 10, type=int), 100)
        
        # Filtros
        status = request.args.get('status')
        
        # Query base
        query = user.appointments
        
        # Aplicar filtros
        if status:
            query = query.filter_by(status=status)
        
        # Ordenar por data mais recente
        query = query.order_by(db.desc('appointment_date'), db.desc('appointment_time'))
        
        # Paginação
        appointments = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'appointments': [apt.to_dict(include_relations=True) for apt in appointments.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': appointments.total,
                'pages': appointments.pages,
                'has_next': appointments.has_next,
                'has_prev': appointments.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@users_bp.route('/deactivate', methods=['POST'])
@jwt_required()
def deactivate_account():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        password = data.get('password', '')
        
        if not password:
            return jsonify({'message': 'Senha é obrigatória para desativar a conta'}), 400
        
        if not user.check_password(password):
            return jsonify({'message': 'Senha incorreta'}), 401
        
        user.is_active = False
        user.updated_at = datetime.now(timezone.utc)
        
        # Se for prestador, desativar também o perfil de prestador
        if user.provider:
            user.provider.is_active = False
            user.provider.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        return jsonify({'message': 'Conta desativada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@users_bp.route('/search', methods=['GET'])
def search_users():
    try:
        # Busca pública de usuários (apenas clientes)
        query = request.args.get('q', '').strip()
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 10, type=int), 50)
        
        if not query:
            return jsonify({'message': 'Parâmetro de busca é obrigatório'}), 400
        
        # Buscar apenas usuários ativos e clientes
        users_query = User.query.filter(
            User.is_active == True,
            User.role == UserRole.CLIENT,
            User.name.ilike(f'%{query}%')
        ).order_by(User.name)
        
        users = users_query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        # Retornar apenas informações básicas por privacidade
        users_data = []
        for user in users.items:
            users_data.append({
                'id': user.id,
                'name': user.name,
                'avatar_url': user.avatar_url
            })
        
        return jsonify({
            'users': users_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': users.total,
                'pages': users.pages,
                'has_next': users.has_next,
                'has_prev': users.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

