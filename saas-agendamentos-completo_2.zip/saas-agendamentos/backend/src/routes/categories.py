from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timezone

from src.models.database import db, User, Category, UserRole

categories_bp = Blueprint('categories', __name__)

@categories_bp.route('/', methods=['GET'])
def list_categories():
    try:
        # Buscar apenas categorias ativas
        categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
        
        return jsonify({
            'categories': [category.to_dict() for category in categories]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@categories_bp.route('/', methods=['POST'])
@jwt_required()
def create_category():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.ADMIN:
            return jsonify({'message': 'Acesso negado'}), 403
        
        data = request.get_json()
        
        # Validar dados obrigatórios
        name = data.get('name', '').strip()
        if not name:
            return jsonify({'message': 'Nome é obrigatório'}), 400
        
        # Verificar se já existe categoria com o mesmo nome
        existing_category = Category.query.filter_by(name=name).first()
        if existing_category:
            return jsonify({'message': 'Já existe uma categoria com este nome'}), 409
        
        description = data.get('description', '').strip()
        icon = data.get('icon', '').strip()
        color = data.get('color', '#3B82F6').strip()
        
        # Validar cor (formato hex)
        import re
        if not re.match(r'^#[0-9A-Fa-f]{6}$', color):
            return jsonify({'message': 'Cor deve estar no formato hexadecimal (#RRGGBB)'}), 400
        
        # Criar categoria
        category = Category(
            name=name,
            description=description,
            icon=icon,
            color=color
        )
        
        db.session.add(category)
        db.session.commit()
        
        return jsonify({
            'message': 'Categoria criada com sucesso',
            'category': category.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@categories_bp.route('/<int:category_id>', methods=['PUT'])
@jwt_required()
def update_category(category_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.ADMIN:
            return jsonify({'message': 'Acesso negado'}), 403
        
        category = Category.query.get(category_id)
        if not category:
            return jsonify({'message': 'Categoria não encontrada'}), 404
        
        data = request.get_json()
        
        # Atualizar campos
        if 'name' in data:
            new_name = data['name'].strip()
            if new_name != category.name:
                # Verificar se já existe outra categoria com o mesmo nome
                existing_category = Category.query.filter(
                    Category.name == new_name,
                    Category.id != category_id
                ).first()
                if existing_category:
                    return jsonify({'message': 'Já existe uma categoria com este nome'}), 409
                category.name = new_name
        
        if 'description' in data:
            category.description = data['description'].strip()
        
        if 'icon' in data:
            category.icon = data['icon'].strip()
        
        if 'color' in data:
            color = data['color'].strip()
            # Validar cor (formato hex)
            import re
            if not re.match(r'^#[0-9A-Fa-f]{6}$', color):
                return jsonify({'message': 'Cor deve estar no formato hexadecimal (#RRGGBB)'}), 400
            category.color = color
        
        if 'is_active' in data:
            category.is_active = data['is_active']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Categoria atualizada com sucesso',
            'category': category.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@categories_bp.route('/<int:category_id>', methods=['DELETE'])
@jwt_required()
def delete_category(category_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.ADMIN:
            return jsonify({'message': 'Acesso negado'}), 403
        
        category = Category.query.get(category_id)
        if not category:
            return jsonify({'message': 'Categoria não encontrada'}), 404
        
        # Verificar se há prestadores usando esta categoria
        if category.providers:
            return jsonify({'message': 'Não é possível excluir categoria que está sendo usada por prestadores'}), 400
        
        # Soft delete - marcar como inativa
        category.is_active = False
        db.session.commit()
        
        return jsonify({'message': 'Categoria removida com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@categories_bp.route('/with-providers', methods=['GET'])
def list_categories_with_providers():
    try:
        # Buscar categorias que têm pelo menos um prestador ativo
        categories = db.session.query(Category).join(
            Category.providers
        ).filter(
            Category.is_active == True,
            Provider.is_active == True,
            Provider.is_verified == True
        ).distinct().order_by(Category.name).all()
        
        categories_data = []
        for category in categories:
            category_dict = category.to_dict()
            # Contar prestadores ativos nesta categoria
            active_providers_count = len([
                p for p in category.providers 
                if p.is_active and p.is_verified
            ])
            category_dict['providers_count'] = active_providers_count
            categories_data.append(category_dict)
        
        return jsonify({
            'categories': categories_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

