from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timezone, date, timedelta
from sqlalchemy import func, extract

from src.models.database import (
    db, User, Provider, Appointment, Service, Category,
    UserRole, AppointmentStatus, PlanType
)

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator para verificar se o usuário é admin"""
    def decorated_function(*args, **kwargs):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.ADMIN:
            return jsonify({'message': 'Acesso negado'}), 403
        
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/dashboard', methods=['GET'])
@jwt_required()
@admin_required
def get_admin_dashboard():
    try:
        # Estatísticas gerais
        total_users = User.query.filter_by(is_active=True).count()
        total_providers = Provider.query.filter_by(is_active=True).count()
        total_appointments = Appointment.query.count()
        pending_providers = Provider.query.filter_by(is_verified=False, is_active=True).count()
        
        # Estatísticas do mês atual
        today = date.today()
        current_month_start = today.replace(day=1)
        
        monthly_appointments = Appointment.query.filter(
            Appointment.created_at >= current_month_start
        ).count()
        
        monthly_users = User.query.filter(
            User.created_at >= current_month_start
        ).count()
        
        monthly_providers = Provider.query.filter(
            Provider.created_at >= current_month_start
        ).count()
        
        # Agendamentos por status
        appointment_stats = db.session.query(
            Appointment.status,
            func.count(Appointment.id)
        ).group_by(Appointment.status).all()
        
        status_counts = {status.value: 0 for status in AppointmentStatus}
        for status, count in appointment_stats:
            status_counts[status.value] = count
        
        # Prestadores por plano
        plan_stats = db.session.query(
            Provider.plan,
            func.count(Provider.id)
        ).group_by(Provider.plan).all()
        
        plan_counts = {plan.value: 0 for plan in PlanType}
        for plan, count in plan_stats:
            plan_counts[plan.value] = count
        
        # Agendamentos dos últimos 7 dias
        last_week = today - timedelta(days=7)
        daily_appointments = db.session.query(
            Appointment.appointment_date,
            func.count(Appointment.id)
        ).filter(
            Appointment.appointment_date >= last_week
        ).group_by(Appointment.appointment_date).all()
        
        daily_stats = {}
        for i in range(7):
            day = last_week + timedelta(days=i)
            daily_stats[day.isoformat()] = 0
        
        for appointment_date, count in daily_appointments:
            daily_stats[appointment_date.isoformat()] = count
        
        return jsonify({
            'general_stats': {
                'total_users': total_users,
                'total_providers': total_providers,
                'total_appointments': total_appointments,
                'pending_providers': pending_providers
            },
            'monthly_stats': {
                'appointments': monthly_appointments,
                'users': monthly_users,
                'providers': monthly_providers
            },
            'appointment_status_stats': status_counts,
            'plan_stats': plan_counts,
            'daily_appointments': daily_stats
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@admin_required
def list_users():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        search = request.args.get('search', '').strip()
        role = request.args.get('role')
        is_active = request.args.get('is_active')
        
        # Query base
        query = User.query
        
        # Aplicar filtros
        if search:
            query = query.filter(
                db.or_(
                    User.name.ilike(f'%{search}%'),
                    User.email.ilike(f'%{search}%')
                )
            )
        
        if role:
            query = query.filter_by(role=role)
        
        if is_active is not None:
            query = query.filter_by(is_active=is_active.lower() == 'true')
        
        # Ordenação
        query = query.order_by(db.desc(User.created_at))
        
        # Paginação
        users = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return jsonify({
            'users': [user.to_dict() for user in users.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': users.total,
                'pages': users.pages,
                'has_next': users.has_next,
                'has_prev': users.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/providers', methods=['GET'])
@jwt_required()
@admin_required
def list_providers():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        search = request.args.get('search', '').strip()
        is_verified = request.args.get('is_verified')
        is_active = request.args.get('is_active')
        plan = request.args.get('plan')
        
        # Query base
        query = Provider.query
        
        # Aplicar filtros
        if search:
            query = query.filter(
                db.or_(
                    Provider.business_name.ilike(f'%{search}%'),
                    Provider.city.ilike(f'%{search}%')
                )
            )
        
        if is_verified is not None:
            query = query.filter_by(is_verified=is_verified.lower() == 'true')
        
        if is_active is not None:
            query = query.filter_by(is_active=is_active.lower() == 'true')
        
        if plan:
            query = query.filter_by(plan=plan)
        
        # Ordenação
        query = query.order_by(db.desc(Provider.created_at))
        
        # Paginação
        providers = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return jsonify({
            'providers': [provider.to_dict(include_user=True) for provider in providers.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': providers.total,
                'pages': providers.pages,
                'has_next': providers.has_next,
                'has_prev': providers.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/providers/<int:provider_id>/verify', methods=['POST'])
@jwt_required()
@admin_required
def verify_provider(provider_id):
    try:
        provider = Provider.query.get(provider_id)
        if not provider:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        data = request.get_json()
        is_verified = data.get('is_verified', True)
        
        provider.is_verified = is_verified
        provider.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        status = 'verificado' if is_verified else 'não verificado'
        return jsonify({
            'message': f'Prestador {status} com sucesso',
            'provider': provider.to_dict(include_user=True)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/providers/<int:provider_id>/plan', methods=['PUT'])
@jwt_required()
@admin_required
def update_provider_plan(provider_id):
    try:
        provider = Provider.query.get(provider_id)
        if not provider:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        data = request.get_json()
        new_plan = data.get('plan')
        
        if not new_plan:
            return jsonify({'message': 'Plano é obrigatório'}), 400
        
        # Validar plano
        valid_plans = [plan.value for plan in PlanType]
        if new_plan not in valid_plans:
            return jsonify({'message': 'Plano inválido'}), 400
        
        # Definir limites baseado no plano
        plan_limits = {
            'free': 50,
            'basic': 200,
            'premium': 999999
        }
        
        provider.plan = PlanType(new_plan)
        provider.monthly_appointments_limit = plan_limits[new_plan]
        provider.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Plano atualizado com sucesso',
            'provider': provider.to_dict(include_user=True)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/users/<int:user_id>/toggle-active', methods=['POST'])
@jwt_required()
@admin_required
def toggle_user_active(user_id):
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        # Não permitir desativar outros admins
        current_user_id = get_jwt_identity()
        if user.role == UserRole.ADMIN and user.id != current_user_id:
            return jsonify({'message': 'Não é possível desativar outros administradores'}), 403
        
        user.is_active = not user.is_active
        user.updated_at = datetime.now(timezone.utc)
        
        # Se for prestador, também atualizar o status do provider
        if user.provider:
            user.provider.is_active = user.is_active
            user.provider.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        status = 'ativado' if user.is_active else 'desativado'
        return jsonify({
            'message': f'Usuário {status} com sucesso',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/appointments', methods=['GET'])
@jwt_required()
@admin_required
def list_appointments():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        status = request.args.get('status')
        provider_id = request.args.get('provider_id', type=int)
        date_from = request.args.get('date_from')
        date_to = request.args.get('date_to')
        
        # Query base
        query = Appointment.query
        
        # Aplicar filtros
        if status:
            query = query.filter_by(status=status)
        
        if provider_id:
            query = query.filter_by(provider_id=provider_id)
        
        if date_from:
            try:
                date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date >= date_from_obj)
            except ValueError:
                return jsonify({'message': 'Formato de date_from inválido'}), 400
        
        if date_to:
            try:
                date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date <= date_to_obj)
            except ValueError:
                return jsonify({'message': 'Formato de date_to inválido'}), 400
        
        # Ordenação
        query = query.order_by(
            db.desc(Appointment.appointment_date),
            db.desc(Appointment.appointment_time)
        )
        
        # Paginação
        appointments = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return jsonify({
            'appointments': [apt.to_dict(include_relations=True) for apt in appointments.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': appointments.total,
                'pages': appointments.pages,
                'has_next': appointments.has_next,
                'has_prev': appointments.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@admin_bp.route('/reports/revenue', methods=['GET'])
@jwt_required()
@admin_required
def get_revenue_report():
    try:
        # Parâmetros de período
        year = request.args.get('year', datetime.now().year, type=int)
        month = request.args.get('month', type=int)
        
        # Query base para agendamentos completados
        query = db.session.query(
            extract('month', Appointment.appointment_date).label('month'),
            func.count(Appointment.id).label('appointments_count'),
            func.sum(Service.price).label('total_revenue')
        ).join(Service).filter(
            Appointment.status == AppointmentStatus.COMPLETED,
            extract('year', Appointment.appointment_date) == year
        )
        
        if month:
            query = query.filter(extract('month', Appointment.appointment_date) == month)
            
        results = query.group_by(extract('month', Appointment.appointment_date)).all()
        
        # Organizar dados por mês
        monthly_data = {}
        for i in range(1, 13):
            monthly_data[i] = {
                'month': i,
                'appointments_count': 0,
                'total_revenue': 0
            }
        
        for result in results:
            monthly_data[result.month] = {
                'month': result.month,
                'appointments_count': result.appointments_count,
                'total_revenue': float(result.total_revenue or 0)
            }
        
        return jsonify({
            'year': year,
            'monthly_revenue': list(monthly_data.values())
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

