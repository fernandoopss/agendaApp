from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timezone, date, time
import re

from src.models.database import db, User, Provider, Category, UserRole, PlanType

providers_bp = Blueprint('providers', __name__)

@providers_bp.route('/', methods=['GET'])
def list_providers():
    try:
        # Parâmetros de busca e filtros
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 12, type=int), 50)
        search = request.args.get('search', '').strip()
        city = request.args.get('city', '').strip()
        category_id = request.args.get('category_id', type=int)
        
        # Query base - apenas prestadores ativos e verificados
        query = Provider.query.filter(
            Provider.is_active == True,
            Provider.is_verified == True
        )
        
        # Aplicar filtros
        if search:
            query = query.filter(
                db.or_(
                    Provider.business_name.ilike(f'%{search}%'),
                    Provider.description.ilike(f'%{search}%')
                )
            )
        
        if city:
            query = query.filter(Provider.city.ilike(f'%{city}%'))
        
        if category_id:
            query = query.join(Provider.categories).filter(Category.id == category_id)
        
        # Ordenação
        sort_by = request.args.get('sort', 'name')
        if sort_by == 'name':
            query = query.order_by(Provider.business_name)
        elif sort_by == 'newest':
            query = query.order_by(db.desc(Provider.created_at))
        else:
            query = query.order_by(Provider.business_name)
        
        # Paginação
        providers = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return jsonify({
            'providers': [provider.to_dict() for provider in providers.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': providers.total,
                'pages': providers.pages,
                'has_next': providers.has_next,
                'has_prev': providers.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/<slug>', methods=['GET'])
def get_provider_by_slug(slug):
    try:
        provider = Provider.query.filter_by(
            slug=slug,
            is_active=True
        ).first()
        
        if not provider:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        # Incluir serviços ativos
        services = provider.services.filter_by(is_active=True).order_by('display_order', 'name').all()
        
        provider_data = provider.to_dict()
        provider_data['services'] = [service.to_dict() for service in services]
        
        return jsonify({'provider': provider_data}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_provider_profile():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        return jsonify({'provider': user.provider.to_dict(include_user=True)}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_provider_profile():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        data = request.get_json()
        provider = user.provider
        
        # Campos que podem ser atualizados
        if 'business_name' in data:
            provider.business_name = data['business_name'].strip()
        
        if 'slug' in data:
            new_slug = data['slug'].strip()
            if new_slug != provider.slug:
                # Validar slug
                if not re.match(r'^[a-zA-Z0-9_-]+$', new_slug):
                    return jsonify({'message': 'Slug deve conter apenas letras, números, hífens e underscores'}), 400
                
                if Provider.query.filter_by(slug=new_slug).first():
                    return jsonify({'message': 'Slug já está em uso'}), 409
                
                provider.slug = new_slug
        
        if 'description' in data:
            provider.description = data['description']
        
        if 'address' in data:
            provider.address = data['address']
        
        if 'city' in data:
            provider.city = data['city']
        
        if 'state' in data:
            provider.state = data['state']
        
        if 'zip_code' in data:
            provider.zip_code = data['zip_code']
        
        if 'latitude' in data and 'longitude' in data:
            provider.latitude = data['latitude']
            provider.longitude = data['longitude']
        
        if 'logo_url' in data:
            provider.logo_url = data['logo_url']
        
        if 'cover_url' in data:
            provider.cover_url = data['cover_url']
        
        if 'website' in data:
            provider.website = data['website']
        
        if 'instagram' in data:
            provider.instagram = data['instagram']
        
        if 'facebook' in data:
            provider.facebook = data['facebook']
        
        if 'whatsapp' in data:
            provider.whatsapp = data['whatsapp']
        
        if 'working_hours' in data:
            provider.working_hours = data['working_hours']
        
        if 'advance_booking_days' in data:
            provider.advance_booking_days = data['advance_booking_days']
        
        if 'cancellation_policy' in data:
            provider.cancellation_policy = data['cancellation_policy']
        
        if 'primary_color' in data:
            provider.primary_color = data['primary_color']
        
        if 'secondary_color' in data:
            provider.secondary_color = data['secondary_color']
        
        # Atualizar categorias se fornecidas
        if 'category_ids' in data:
            categories = Category.query.filter(Category.id.in_(data['category_ids'])).all()
            provider.categories = categories
        
        provider.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Perfil atualizado com sucesso',
            'provider': provider.to_dict(include_user=True)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/dashboard', methods=['GET'])
@jwt_required()
def get_provider_dashboard():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        provider = user.provider
        
        # Estatísticas básicas
        today = date.today()
        
        # Agendamentos de hoje
        today_appointments = provider.appointments.filter_by(appointment_date=today).count()
        
        # Agendamentos pendentes
        pending_appointments = provider.appointments.filter_by(status='pending').count()
        
        # Total de agendamentos este mês
        current_month = today.replace(day=1)
        monthly_appointments = provider.appointments.filter(
            db.extract('year', 'appointment_date') == today.year,
            db.extract('month', 'appointment_date') == today.month
        ).count()
        
        # Próximos agendamentos (próximos 7 dias)
        from datetime import timedelta
        next_week = today + timedelta(days=7)
        upcoming_appointments = provider.appointments.filter(
            db.and_(
                'appointment_date' >= today,
                'appointment_date' <= next_week,
                'status' != 'cancelled'
            )
        ).order_by('appointment_date', 'appointment_time').limit(10).all()
        
        return jsonify({
            'stats': {
                'today_appointments': today_appointments,
                'pending_appointments': pending_appointments,
                'monthly_appointments': monthly_appointments,
                'monthly_limit': provider.monthly_appointments_limit,
                'plan': provider.plan.value
            },
            'upcoming_appointments': [apt.to_dict(include_relations=True) for apt in upcoming_appointments]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/available-times', methods=['GET'])
def get_available_times():
    try:
        provider_id = request.args.get('provider_id', type=int)
        service_id = request.args.get('service_id', type=int)
        date_str = request.args.get('date')
        
        if not all([provider_id, service_id, date_str]):
            return jsonify({'message': 'provider_id, service_id e date são obrigatórios'}), 400
        
        try:
            appointment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'message': 'Formato de data inválido. Use YYYY-MM-DD'}), 400
        
        # Verificar se a data não é no passado
        if appointment_date < date.today():
            return jsonify({'message': 'Não é possível agendar para datas passadas'}), 400
        
        provider = Provider.query.get(provider_id)
        if not provider or not provider.is_active:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        service = provider.services.filter_by(id=service_id, is_active=True).first()
        if not service:
            return jsonify({'message': 'Serviço não encontrado'}), 404
        
        # Verificar limite de antecedência
        max_advance_date = date.today() + timedelta(days=provider.advance_booking_days)
        if appointment_date > max_advance_date:
            return jsonify({'message': f'Agendamento permitido apenas até {provider.advance_booking_days} dias de antecedência'}), 400
        
        # Obter horários de funcionamento para o dia da semana
        weekday = appointment_date.weekday()  # 0 = segunda, 6 = domingo
        working_hours = provider.working_hours or {}
        day_schedule = working_hours.get(str(weekday))
        
        if not day_schedule or not day_schedule.get('is_working', False):
            return jsonify({'available_times': []}), 200
        
        # Gerar slots de horário disponíveis
        start_time = datetime.strptime(day_schedule['start_time'], '%H:%M').time()
        end_time = datetime.strptime(day_schedule['end_time'], '%H:%M').time()
        
        # Obter agendamentos existentes para o dia
        existing_appointments = provider.appointments.filter(
            db.and_(
                'appointment_date' == appointment_date,
                'status' != 'cancelled'
            )
        ).all()
        
        # Gerar slots disponíveis
        available_times = []
        current_time = datetime.combine(appointment_date, start_time)
        end_datetime = datetime.combine(appointment_date, end_time)
        
        while current_time + timedelta(minutes=service.duration_minutes) <= end_datetime:
            slot_start = current_time.time()
            slot_end = (current_time + timedelta(minutes=service.duration_minutes)).time()
            
            # Verificar se o slot não conflita com agendamentos existentes
            is_available = True
            for apt in existing_appointments:
                if not (slot_end <= apt.appointment_time or slot_start >= apt.end_time):
                    is_available = False
                    break
            
            if is_available:
                available_times.append(slot_start.strftime('%H:%M'))
            
            # Avançar para o próximo slot (intervalos de 30 minutos)
            current_time += timedelta(minutes=30)
        
        return jsonify({'available_times': available_times}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@providers_bp.route('/cities', methods=['GET'])
def get_provider_cities():
    try:
        # Buscar cidades únicas onde há prestadores ativos
        cities = db.session.query(Provider.city).filter(
            Provider.is_active == True,
            Provider.is_verified == True,
            Provider.city.isnot(None),
            Provider.city != ''
        ).distinct().order_by(Provider.city).all()
        
        city_list = [city[0] for city in cities if city[0]]
        
        return jsonify({'cities': city_list}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

