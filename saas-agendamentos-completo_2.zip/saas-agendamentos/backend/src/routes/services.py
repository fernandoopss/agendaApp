from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timezone

from src.models.database import db, User, Provider, Service, UserRole

services_bp = Blueprint('services', __name__)

@services_bp.route('/provider/<int:provider_id>', methods=['GET'])
def get_provider_services(provider_id):
    try:
        provider = Provider.query.get(provider_id)
        if not provider or not provider.is_active:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        # Buscar apenas serviços ativos, ordenados
        services = provider.services.filter_by(is_active=True).order_by(
            Service.display_order, Service.name
        ).all()
        
        return jsonify({
            'services': [service.to_dict() for service in services]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@services_bp.route('/', methods=['POST'])
@jwt_required()
def create_service():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['name', 'duration_minutes', 'price']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'Campo {field} é obrigatório'}), 400
        
        name = data['name'].strip()
        description = data.get('description', '').strip()
        duration_minutes = data['duration_minutes']
        price = data['price']
        image_url = data.get('image_url', '')
        display_order = data.get('display_order', 0)
        
        # Validações
        if duration_minutes < 15 or duration_minutes > 480:  # 15 min a 8 horas
            return jsonify({'message': 'Duração deve estar entre 15 e 480 minutos'}), 400
        
        if price < 0:
            return jsonify({'message': 'Preço deve ser maior ou igual a zero'}), 400
        
        # Verificar se já existe serviço com o mesmo nome para este prestador
        existing_service = user.provider.services.filter_by(name=name, is_active=True).first()
        if existing_service:
            return jsonify({'message': 'Já existe um serviço com este nome'}), 409
        
        # Criar serviço
        service = Service(
            provider_id=user.provider.id,
            name=name,
            description=description,
            duration_minutes=duration_minutes,
            price=price,
            image_url=image_url,
            display_order=display_order
        )
        
        db.session.add(service)
        db.session.commit()
        
        return jsonify({
            'message': 'Serviço criado com sucesso',
            'service': service.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@services_bp.route('/<int:service_id>', methods=['PUT'])
@jwt_required()
def update_service(service_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'message': 'Serviço não encontrado'}), 404
        
        # Verificar se o serviço pertence ao prestador
        if service.provider_id != user.provider.id:
            return jsonify({'message': 'Acesso negado'}), 403
        
        data = request.get_json()
        
        # Atualizar campos
        if 'name' in data:
            new_name = data['name'].strip()
            # Verificar se já existe outro serviço com o mesmo nome
            existing_service = user.provider.services.filter(
                Service.name == new_name,
                Service.is_active == True,
                Service.id != service_id
            ).first()
            if existing_service:
                return jsonify({'message': 'Já existe um serviço com este nome'}), 409
            service.name = new_name
        
        if 'description' in data:
            service.description = data['description'].strip()
        
        if 'duration_minutes' in data:
            duration = data['duration_minutes']
            if duration < 15 or duration > 480:
                return jsonify({'message': 'Duração deve estar entre 15 e 480 minutos'}), 400
            service.duration_minutes = duration
        
        if 'price' in data:
            price = data['price']
            if price < 0:
                return jsonify({'message': 'Preço deve ser maior ou igual a zero'}), 400
            service.price = price
        
        if 'image_url' in data:
            service.image_url = data['image_url']
        
        if 'display_order' in data:
            service.display_order = data['display_order']
        
        if 'is_active' in data:
            service.is_active = data['is_active']
        
        service.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Serviço atualizado com sucesso',
            'service': service.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@services_bp.route('/<int:service_id>', methods=['DELETE'])
@jwt_required()
def delete_service(service_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        service = Service.query.get(service_id)
        if not service:
            return jsonify({'message': 'Serviço não encontrado'}), 404
        
        # Verificar se o serviço pertence ao prestador
        if service.provider_id != user.provider.id:
            return jsonify({'message': 'Acesso negado'}), 403
        
        # Verificar se há agendamentos futuros para este serviço
        from datetime import date
        future_appointments = service.appointments.filter(
            db.and_(
                'appointment_date' >= date.today(),
                'status' != 'cancelled'
            )
        ).count()
        
        if future_appointments > 0:
            return jsonify({'message': 'Não é possível excluir serviço com agendamentos futuros'}), 400
        
        # Soft delete - marcar como inativo
        service.is_active = False
        service.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({'message': 'Serviço removido com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@services_bp.route('/my-services', methods=['GET'])
@jwt_required()
def get_my_services():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        # Buscar todos os serviços do prestador (ativos e inativos)
        services = user.provider.services.order_by(
            Service.display_order, Service.name
        ).all()
        
        return jsonify({
            'services': [service.to_dict() for service in services]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@services_bp.route('/reorder', methods=['POST'])
@jwt_required()
def reorder_services():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or user.role != UserRole.PROVIDER:
            return jsonify({'message': 'Acesso negado'}), 403
        
        if not user.provider:
            return jsonify({'message': 'Perfil de prestador não encontrado'}), 404
        
        data = request.get_json()
        service_orders = data.get('service_orders', [])
        
        if not service_orders:
            return jsonify({'message': 'Lista de ordenação é obrigatória'}), 400
        
        # Atualizar ordem dos serviços
        for item in service_orders:
            service_id = item.get('service_id')
            display_order = item.get('display_order', 0)
            
            service = Service.query.filter_by(
                id=service_id,
                provider_id=user.provider.id
            ).first()
            
            if service:
                service.display_order = display_order
                service.updated_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        return jsonify({'message': 'Ordem dos serviços atualizada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

