from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token, create_refresh_token, jwt_required, 
    get_jwt_identity, get_jwt
)
from datetime import datetime, timezone, timedelta
import secrets
import re

from src.models.database import db, User, Provider, RefreshToken, UserRole

auth_bp = Blueprint('auth', __name__)

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    # Mínimo 8 caracteres, pelo menos 1 letra e 1 número
    if len(password) < 8:
        return False
    if not re.search(r'[A-Za-z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    return True

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['email', 'password', 'name', 'role']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'Campo {field} é obrigatório'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        name = data['name'].strip()
        role = data['role']
        phone = data.get('phone', '').strip()
        
        # Validações
        if not validate_email(email):
            return jsonify({'message': 'Email inválido'}), 400
        
        if not validate_password(password):
            return jsonify({'message': 'Senha deve ter pelo menos 8 caracteres, incluindo letras e números'}), 400
        
        if role not in ['client', 'provider']:
            return jsonify({'message': 'Tipo de usuário inválido'}), 400
        
        # Verificar se email já existe
        if User.query.filter_by(email=email).first():
            return jsonify({'message': 'Email já cadastrado'}), 409
        
        # Criar usuário
        user = User(
            email=email,
            name=name,
            phone=phone,
            role=UserRole.PROVIDER if role == 'provider' else UserRole.CLIENT
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.flush()  # Para obter o ID do usuário
        
        # Se for prestador, criar perfil de prestador
        provider = None
        if role == 'provider':
            business_name = data.get('business_name', name)
            slug = data.get('slug', '').strip()
            
            # Gerar slug único se não fornecido
            if not slug:
                base_slug = re.sub(r'[^a-zA-Z0-9]', '', name.lower())
                slug = base_slug
                counter = 1
                while Provider.query.filter_by(slug=slug).first():
                    slug = f"{base_slug}{counter}"
                    counter += 1
            else:
                # Validar slug
                if not re.match(r'^[a-zA-Z0-9_-]+$', slug):
                    return jsonify({'message': 'Slug deve conter apenas letras, números, hífens e underscores'}), 400
                
                if Provider.query.filter_by(slug=slug).first():
                    return jsonify({'message': 'Slug já está em uso'}), 409
            
            provider = Provider(
                user_id=user.id,
                business_name=business_name,
                slug=slug,
                description=data.get('description', ''),
                address=data.get('address', ''),
                city=data.get('city', ''),
                state=data.get('state', ''),
                zip_code=data.get('zip_code', ''),
                whatsapp=phone
            )
            db.session.add(provider)
        
        db.session.commit()
        
        # Criar tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        # Salvar refresh token no banco
        refresh_token_obj = RefreshToken(
            user_id=user.id,
            token=refresh_token,
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        db.session.add(refresh_token_obj)
        db.session.commit()
        
        response_data = {
            'message': 'Usuário criado com sucesso',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        }
        
        if provider:
            response_data['provider'] = provider.to_dict()
        
        return jsonify(response_data), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        
        if not email or not password:
            return jsonify({'message': 'Email e senha são obrigatórios'}), 400
        
        # Buscar usuário
        user = User.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            return jsonify({'message': 'Email ou senha incorretos'}), 401
        
        if not user.is_active:
            return jsonify({'message': 'Conta desativada'}), 401
        
        # Criar tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        # Salvar refresh token no banco
        refresh_token_obj = RefreshToken(
            user_id=user.id,
            token=refresh_token,
            expires_at=datetime.now(timezone.utc) + timedelta(days=7)
        )
        db.session.add(refresh_token_obj)
        db.session.commit()
        
        response_data = {
            'message': 'Login realizado com sucesso',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        }
        
        # Se for prestador, incluir dados do prestador
        if user.role == UserRole.PROVIDER and user.provider:
            response_data['provider'] = user.provider.to_dict()
        
        return jsonify(response_data), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    try:
        current_user_id = get_jwt_identity()
        
        # Verificar se o refresh token existe no banco
        refresh_token = request.headers.get('Authorization', '').replace('Bearer ', '')
        token_obj = RefreshToken.query.filter_by(
            user_id=current_user_id,
            token=refresh_token
        ).first()
        
        if not token_obj or token_obj.is_expired():
            return jsonify({'message': 'Refresh token inválido ou expirado'}), 401
        
        # Criar novo access token
        new_access_token = create_access_token(identity=current_user_id)
        
        return jsonify({
            'access_token': new_access_token
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    try:
        current_user_id = get_jwt_identity()
        
        # Remover refresh tokens do usuário
        RefreshToken.query.filter_by(user_id=current_user_id).delete()
        db.session.commit()
        
        return jsonify({'message': 'Logout realizado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        response_data = {
            'user': user.to_dict()
        }
        
        # Se for prestador, incluir dados do prestador
        if user.role == UserRole.PROVIDER and user.provider:
            response_data['provider'] = user.provider.to_dict()
        
        return jsonify(response_data), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')
        
        if not current_password or not new_password:
            return jsonify({'message': 'Senha atual e nova senha são obrigatórias'}), 400
        
        user = User.query.get(current_user_id)
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        if not user.check_password(current_password):
            return jsonify({'message': 'Senha atual incorreta'}), 401
        
        if not validate_password(new_password):
            return jsonify({'message': 'Nova senha deve ter pelo menos 8 caracteres, incluindo letras e números'}), 400
        
        user.set_password(new_password)
        user.updated_at = datetime.now(timezone.utc)
        
        # Remover todos os refresh tokens (forçar novo login)
        RefreshToken.query.filter_by(user_id=user.id).delete()
        
        db.session.commit()
        
        return jsonify({'message': 'Senha alterada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        data = request.get_json()
        email = data.get('email', '').lower().strip()
        
        if not email:
            return jsonify({'message': 'Email é obrigatório'}), 400
        
        user = User.query.filter_by(email=email).first()
        
        # Sempre retornar sucesso por segurança (não revelar se email existe)
        if user:
            # TODO: Implementar envio de email com token de reset
            # Por enquanto, apenas log
            print(f"Reset password requested for user {user.id}")
        
        return jsonify({'message': 'Se o email estiver cadastrado, você receberá instruções para redefinir sua senha'}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

