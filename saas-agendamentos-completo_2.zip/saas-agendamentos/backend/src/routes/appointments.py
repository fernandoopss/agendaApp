from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, jwt_required
from datetime import datetime, timezone, date, time, timedelta
import re

from src.models.database import (
    db, User, Provider, Service, Appointment, 
    UserRole, AppointmentStatus
)

appointments_bp = Blueprint('appointments', __name__)

@appointments_bp.route('/', methods=['POST'])
def create_appointment():
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['provider_id', 'service_id', 'appointment_date', 'appointment_time']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'Campo {field} é obrigatório'}), 400
        
        provider_id = data['provider_id']
        service_id = data['service_id']
        appointment_date_str = data['appointment_date']
        appointment_time_str = data['appointment_time']
        notes = data.get('notes', '')
        
        # Dados do cliente (se não estiver logado)
        client_name = data.get('client_name', '').strip()
        client_phone = data.get('client_phone', '').strip()
        client_email = data.get('client_email', '').strip()
        
        # Validar formato de data e hora
        try:
            appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%d').date()
            appointment_time = datetime.strptime(appointment_time_str, '%H:%M').time()
        except ValueError:
            return jsonify({'message': 'Formato de data ou hora inválido'}), 400
        
        # Verificar se a data não é no passado
        if appointment_date < date.today():
            return jsonify({'message': 'Não é possível agendar para datas passadas'}), 400
        
        # Verificar se o prestador existe e está ativo
        provider = Provider.query.get(provider_id)
        if not provider or not provider.is_active:
            return jsonify({'message': 'Prestador não encontrado ou inativo'}), 404
        
        # Verificar se o serviço existe e pertence ao prestador
        service = provider.services.filter_by(id=service_id, is_active=True).first()
        if not service:
            return jsonify({'message': 'Serviço não encontrado'}), 404
        
        # Verificar limite de antecedência
        max_advance_date = date.today() + timedelta(days=provider.advance_booking_days)
        if appointment_date > max_advance_date:
            return jsonify({'message': f'Agendamento permitido apenas até {provider.advance_booking_days} dias de antecedência'}), 400
        
        # Calcular horário de término
        start_datetime = datetime.combine(appointment_date, appointment_time)
        end_datetime = start_datetime + timedelta(minutes=service.duration_minutes)
        end_time = end_datetime.time()
        
        # Verificar se o horário está dentro do funcionamento
        weekday = appointment_date.weekday()
        working_hours = provider.working_hours or {}
        day_schedule = working_hours.get(str(weekday))
        
        if not day_schedule or not day_schedule.get('is_working', False):
            return jsonify({'message': 'Prestador não trabalha neste dia da semana'}), 400
        
        work_start = datetime.strptime(day_schedule['start_time'], '%H:%M').time()
        work_end = datetime.strptime(day_schedule['end_time'], '%H:%M').time()
        
        if appointment_time < work_start or end_time > work_end:
            return jsonify({'message': 'Horário fora do funcionamento do prestador'}), 400
        
        # Verificar conflitos com outros agendamentos
        conflicting_appointment = Appointment.query.filter(
            Appointment.provider_id == provider_id,
            Appointment.appointment_date == appointment_date,
            Appointment.status != AppointmentStatus.CANCELLED,
            db.or_(
                db.and_(
                    Appointment.appointment_time <= appointment_time,
                    Appointment.end_time > appointment_time
                ),
                db.and_(
                    Appointment.appointment_time < end_time,
                    Appointment.end_time >= end_time
                ),
                db.and_(
                    Appointment.appointment_time >= appointment_time,
                    Appointment.end_time <= end_time
                )
            )
        ).first()
        
        if conflicting_appointment:
            return jsonify({'message': 'Horário não disponível'}), 409
        
        # Verificar limite mensal do prestador
        current_month_count = Appointment.query.filter(
            Appointment.provider_id == provider_id,
            db.extract('year', Appointment.appointment_date) == appointment_date.year,
            db.extract('month', Appointment.appointment_date) == appointment_date.month,
            Appointment.status != AppointmentStatus.CANCELLED
        ).count()
        
        if current_month_count >= provider.monthly_appointments_limit:
            return jsonify({'message': 'Prestador atingiu o limite mensal de agendamentos'}), 400
        
        # Obter usuário logado (se houver)
        user_id = None
        try:
            from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
            verify_jwt_in_request(optional=True)
            user_id = get_jwt_identity()
        except:
            pass
        
        # Se não há usuário logado, validar dados do cliente
        if not user_id:
            if not client_name or not client_phone:
                return jsonify({'message': 'Nome e telefone são obrigatórios para agendamento sem cadastro'}), 400
            
            if client_email and not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', client_email):
                return jsonify({'message': 'Email inválido'}), 400
        
        # Criar agendamento
        appointment = Appointment(
            user_id=user_id,
            provider_id=provider_id,
            service_id=service_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            end_time=end_time,
            notes=notes,
            client_name=client_name if not user_id else None,
            client_phone=client_phone if not user_id else None,
            client_email=client_email if not user_id else None
        )
        
        db.session.add(appointment)
        
        # Atualizar contador mensal do prestador
        provider.monthly_appointments_count = current_month_count + 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Agendamento criado com sucesso',
            'appointment': appointment.to_dict(include_relations=True)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@appointments_bp.route('/<int:appointment_id>', methods=['GET'])
@jwt_required()
def get_appointment(appointment_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'message': 'Agendamento não encontrado'}), 404
        
        # Verificar permissão de acesso
        can_access = False
        if user.role == UserRole.ADMIN:
            can_access = True
        elif user.role == UserRole.CLIENT and appointment.user_id == user.id:
            can_access = True
        elif user.role == UserRole.PROVIDER and user.provider and appointment.provider_id == user.provider.id:
            can_access = True
        
        if not can_access:
            return jsonify({'message': 'Acesso negado'}), 403
        
        return jsonify({'appointment': appointment.to_dict(include_relations=True)}), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@appointments_bp.route('/<int:appointment_id>/status', methods=['PUT'])
@jwt_required()
def update_appointment_status(appointment_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        new_status = data.get('status')
        provider_notes = data.get('provider_notes', '')
        
        if not new_status:
            return jsonify({'message': 'Status é obrigatório'}), 400
        
        # Validar status
        valid_statuses = [status.value for status in AppointmentStatus]
        if new_status not in valid_statuses:
            return jsonify({'message': 'Status inválido'}), 400
        
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'message': 'Agendamento não encontrado'}), 404
        
        # Verificar permissões
        can_update = False
        if user.role == UserRole.ADMIN:
            can_update = True
        elif user.role == UserRole.PROVIDER and user.provider and appointment.provider_id == user.provider.id:
            can_update = True
        elif user.role == UserRole.CLIENT and appointment.user_id == user.id and new_status == 'cancelled':
            # Cliente só pode cancelar
            can_update = True
        
        if not can_update:
            return jsonify({'message': 'Acesso negado'}), 403
        
        # Atualizar status
        old_status = appointment.status
        appointment.status = AppointmentStatus(new_status)
        appointment.updated_at = datetime.now(timezone.utc)
        
        if provider_notes:
            appointment.provider_notes = provider_notes
        
        # Atualizar timestamps específicos
        now = datetime.now(timezone.utc)
        if new_status == 'confirmed' and old_status != AppointmentStatus.CONFIRMED:
            appointment.confirmed_at = now
        elif new_status == 'cancelled' and old_status != AppointmentStatus.CANCELLED:
            appointment.cancelled_at = now
        elif new_status == 'completed' and old_status != AppointmentStatus.COMPLETED:
            appointment.completed_at = now
        
        db.session.commit()
        
        return jsonify({
            'message': 'Status atualizado com sucesso',
            'appointment': appointment.to_dict(include_relations=True)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@appointments_bp.route('/provider/<int:provider_id>', methods=['GET'])
@jwt_required()
def get_provider_appointments(provider_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        # Verificar permissão
        can_access = False
        if user.role == UserRole.ADMIN:
            can_access = True
        elif user.role == UserRole.PROVIDER and user.provider and user.provider.id == provider_id:
            can_access = True
        
        if not can_access:
            return jsonify({'message': 'Acesso negado'}), 403
        
        # Parâmetros de filtro
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        status = request.args.get('status')
        date_from = request.args.get('date_from')
        date_to = request.args.get('date_to')
        
        # Query base
        query = Appointment.query.filter_by(provider_id=provider_id)
        
        # Aplicar filtros
        if status:
            query = query.filter_by(status=status)
        
        if date_from:
            try:
                date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date >= date_from_obj)
            except ValueError:
                return jsonify({'message': 'Formato de data_from inválido'}), 400
        
        if date_to:
            try:
                date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
                query = query.filter(Appointment.appointment_date <= date_to_obj)
            except ValueError:
                return jsonify({'message': 'Formato de date_to inválido'}), 400
        
        # Ordenar por data e hora
        query = query.order_by(
            db.desc(Appointment.appointment_date),
            db.desc(Appointment.appointment_time)
        )
        
        # Paginação
        appointments = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        return jsonify({
            'appointments': [apt.to_dict(include_relations=True) for apt in appointments.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': appointments.total,
                'pages': appointments.pages,
                'has_next': appointments.has_next,
                'has_prev': appointments.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@appointments_bp.route('/<int:appointment_id>', methods=['DELETE'])
@jwt_required()
def delete_appointment(appointment_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Usuário não encontrado'}), 404
        
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'message': 'Agendamento não encontrado'}), 404
        
        # Verificar permissões (apenas admin pode deletar)
        if user.role != UserRole.ADMIN:
            return jsonify({'message': 'Acesso negado'}), 403
        
        db.session.delete(appointment)
        db.session.commit()
        
        return jsonify({'message': 'Agendamento deletado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

@appointments_bp.route('/calendar/<int:provider_id>', methods=['GET'])
def get_provider_calendar(provider_id):
    try:
        # Parâmetros
        year = request.args.get('year', datetime.now().year, type=int)
        month = request.args.get('month', datetime.now().month, type=int)
        
        # Validar mês e ano
        if month < 1 or month > 12:
            return jsonify({'message': 'Mês inválido'}), 400
        
        if year < 2020 or year > 2030:
            return jsonify({'message': 'Ano inválido'}), 400
        
        # Verificar se o prestador existe
        provider = Provider.query.get(provider_id)
        if not provider or not provider.is_active:
            return jsonify({'message': 'Prestador não encontrado'}), 404
        
        # Buscar agendamentos do mês
        from calendar import monthrange
        _, last_day = monthrange(year, month)
        
        start_date = date(year, month, 1)
        end_date = date(year, month, last_day)
        
        appointments = Appointment.query.filter(
            Appointment.provider_id == provider_id,
            Appointment.appointment_date >= start_date,
            Appointment.appointment_date <= end_date,
            Appointment.status != AppointmentStatus.CANCELLED
        ).order_by(Appointment.appointment_date, Appointment.appointment_time).all()
        
        # Agrupar por data
        calendar_data = {}
        for appointment in appointments:
            date_str = appointment.appointment_date.isoformat()
            if date_str not in calendar_data:
                calendar_data[date_str] = []
            
            calendar_data[date_str].append({
                'id': appointment.id,
                'time': appointment.appointment_time.strftime('%H:%M'),
                'end_time': appointment.end_time.strftime('%H:%M'),
                'service_name': appointment.service.name if appointment.service else '',
                'client_name': appointment.client.name if appointment.client else appointment.client_name,
                'status': appointment.status.value
            })
        
        return jsonify({
            'year': year,
            'month': month,
            'calendar': calendar_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Erro interno: {str(e)}'}), 500

