from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash
import enum

db = SQLAlchemy()

class UserRole(enum.Enum):
    CLIENT = "client"
    PROVIDER = "provider"
    ADMIN = "admin"

class AppointmentStatus(enum.Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    NO_SHOW = "no_show"

class PlanType(enum.Enum):
    FREE = "free"
    BASIC = "basic"
    PREMIUM = "premium"

# Tabela de associação para categorias de prestadores
provider_categories = db.Table('provider_categories',
    db.Column('provider_id', db.Integer, db.ForeignKey('providers.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('categories.id'), primary_key=True)
)

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    avatar_url = db.Column(db.String(255))
    role = db.Column(db.Enum(UserRole), default=UserRole.CLIENT, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    email_verified = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relacionamentos
    appointments = db.relationship('Appointment', foreign_keys='Appointment.user_id', backref='client', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'phone': self.phone,
            'avatar_url': self.avatar_url,
            'role': self.role.value,
            'is_active': self.is_active,
            'email_verified': self.email_verified,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    icon = db.Column(db.String(100))  # Nome do ícone
    color = db.Column(db.String(7))   # Cor em hex
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'color': self.color,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }

class Provider(db.Model):
    __tablename__ = 'providers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    business_name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(100), unique=True, nullable=False, index=True)
    description = db.Column(db.Text)
    address = db.Column(db.String(255))
    city = db.Column(db.String(100))
    state = db.Column(db.String(50))
    zip_code = db.Column(db.String(20))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    logo_url = db.Column(db.String(255))
    cover_url = db.Column(db.String(255))
    website = db.Column(db.String(255))
    instagram = db.Column(db.String(100))
    facebook = db.Column(db.String(100))
    whatsapp = db.Column(db.String(20))
    
    # Configurações de funcionamento
    working_hours = db.Column(db.JSON)  # JSON com horários por dia da semana
    advance_booking_days = db.Column(db.Integer, default=30)  # Quantos dias de antecedência
    cancellation_policy = db.Column(db.Text)
    
    # Configurações visuais
    primary_color = db.Column(db.String(7), default='#3B82F6')
    secondary_color = db.Column(db.String(7), default='#1E40AF')
    
    # Plano e limites
    plan = db.Column(db.Enum(PlanType), default=PlanType.FREE, nullable=False)
    monthly_appointments_limit = db.Column(db.Integer, default=50)
    monthly_appointments_count = db.Column(db.Integer, default=0)
    
    # Status
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relacionamentos
    user = db.relationship('User', backref=db.backref('provider', uselist=False))
    categories = db.relationship('Category', secondary=provider_categories, backref='providers')
    services = db.relationship('Service', backref='provider', lazy='dynamic', cascade='all, delete-orphan')
    appointments = db.relationship('Appointment', foreign_keys='Appointment.provider_id', backref='provider', lazy='dynamic')
    
    def to_dict(self, include_user=False):
        data = {
            'id': self.id,
            'business_name': self.business_name,
            'slug': self.slug,
            'description': self.description,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'zip_code': self.zip_code,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'logo_url': self.logo_url,
            'cover_url': self.cover_url,
            'website': self.website,
            'instagram': self.instagram,
            'facebook': self.facebook,
            'whatsapp': self.whatsapp,
            'working_hours': self.working_hours,
            'advance_booking_days': self.advance_booking_days,
            'cancellation_policy': self.cancellation_policy,
            'primary_color': self.primary_color,
            'secondary_color': self.secondary_color,
            'plan': self.plan.value,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'created_at': self.created_at.isoformat(),
            'categories': [cat.to_dict() for cat in self.categories]
        }
        
        if include_user and self.user:
            data['user'] = self.user.to_dict()
            
        return data

class Service(db.Model):
    __tablename__ = 'services'
    
    id = db.Column(db.Integer, primary_key=True)
    provider_id = db.Column(db.Integer, db.ForeignKey('providers.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    duration_minutes = db.Column(db.Integer, nullable=False)  # Duração em minutos
    price = db.Column(db.Numeric(10, 2), nullable=False)
    image_url = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    display_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relacionamentos
    appointments = db.relationship('Appointment', backref='service', lazy='dynamic')
    
    def to_dict(self):
        return {
            'id': self.id,
            'provider_id': self.provider_id,
            'name': self.name,
            'description': self.description,
            'duration_minutes': self.duration_minutes,
            'price': float(self.price),
            'image_url': self.image_url,
            'is_active': self.is_active,
            'display_order': self.display_order,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    provider_id = db.Column(db.Integer, db.ForeignKey('providers.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    
    # Data e hora do agendamento
    appointment_date = db.Column(db.Date, nullable=False, index=True)
    appointment_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    
    # Status e observações
    status = db.Column(db.Enum(AppointmentStatus), default=AppointmentStatus.PENDING, nullable=False)
    notes = db.Column(db.Text)  # Observações do cliente
    provider_notes = db.Column(db.Text)  # Observações do prestador
    
    # Informações de contato (caso o cliente não tenha conta)
    client_name = db.Column(db.String(100))
    client_phone = db.Column(db.String(20))
    client_email = db.Column(db.String(120))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    confirmed_at = db.Column(db.DateTime)
    cancelled_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    def to_dict(self, include_relations=False):
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'provider_id': self.provider_id,
            'service_id': self.service_id,
            'appointment_date': self.appointment_date.isoformat(),
            'appointment_time': self.appointment_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'status': self.status.value,
            'notes': self.notes,
            'provider_notes': self.provider_notes,
            'client_name': self.client_name,
            'client_phone': self.client_phone,
            'client_email': self.client_email,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'confirmed_at': self.confirmed_at.isoformat() if self.confirmed_at else None,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }
        
        if include_relations:
            if self.client:
                data['client'] = self.client.to_dict()
            if self.provider:
                data['provider'] = self.provider.to_dict()
            if self.service:
                data['service'] = self.service.to_dict()
                
        return data

class RefreshToken(db.Model):
    __tablename__ = 'refresh_tokens'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    token = db.Column(db.String(255), nullable=False, unique=True, index=True)
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    
    # Relacionamentos
    user = db.relationship('User', backref='refresh_tokens')
    
    def is_expired(self):
        return datetime.now(timezone.utc) > self.expires_at.replace(tzinfo=timezone.utc)

