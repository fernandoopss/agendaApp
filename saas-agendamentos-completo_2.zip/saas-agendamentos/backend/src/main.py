import os
import sys
from datetime import timedelta
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from src.models.database import db
from src.routes.auth import auth_bp
from src.routes.users import users_bp
from src.routes.providers import providers_bp
from src.routes.appointments import appointments_bp
from src.routes.services import services_bp
from src.routes.categories import categories_bp
from src.routes.admin import admin_bp

def create_app():
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Configurações básicas
    app.config['SECRET_KEY'] = os.getenv('JWT_SECRET', 'seu-jwt-secret-super-seguro')
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET', 'seu-jwt-secret-super-seguro')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=15)
    app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=7)
    
    # Configuração do banco de dados
    database_url = os.getenv('DATABASE_URL', 'sqlite:///app.db')
    if database_url.startswith('postgres://'):
        database_url = database_url.replace('postgres://', 'postgresql://', 1)
    
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    
    # Configuração de upload
    app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_FILE_SIZE', 5242880))  # 5MB
    app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_PATH', '/app/uploads')
    
    # Inicializar extensões
    CORS(app, origins=["*"])  # Permitir CORS para todas as origens
    jwt = JWTManager(app)
    
    # Rate limiting
    limiter = Limiter(
        app,
        key_func=get_remote_address,
        default_limits=["100 per hour"]
    )
    
    # Inicializar banco de dados
    db.init_app(app)
    
    # Registrar blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(providers_bp, url_prefix='/api/providers')
    app.register_blueprint(appointments_bp, url_prefix='/api/appointments')
    app.register_blueprint(services_bp, url_prefix='/api/services')
    app.register_blueprint(categories_bp, url_prefix='/api/categories')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    
    # Criar tabelas
    with app.app_context():
        db.create_all()
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        return jsonify({
            'status': 'healthy',
            'service': 'SaaS Agendamentos API',
            'version': '1.0.0'
        })
    
    # Endpoint de informações da API
    @app.route('/api')
    def api_info():
        return jsonify({
            'name': 'SaaS Agendamentos API',
            'version': '1.0.0',
            'description': 'API para sistema de agendamento online',
            'endpoints': {
                'auth': '/api/auth',
                'users': '/api/users',
                'providers': '/api/providers',
                'appointments': '/api/appointments',
                'services': '/api/services',
                'categories': '/api/categories',
                'admin': '/api/admin'
            }
        })
    
    # Servir arquivos estáticos (frontend)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve(path):
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return "Static folder not configured", 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            index_path = os.path.join(static_folder_path, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(static_folder_path, 'index.html')
            else:
                return jsonify({'message': 'Frontend não encontrado'}), 404
    
    # Handlers de erro JWT
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({'message': 'Token expirado'}), 401
    
    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({'message': 'Token inválido'}), 401
    
    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({'message': 'Token de autorização necessário'}), 401
    
    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('NODE_ENV', 'development') == 'development'
    app.run(host='0.0.0.0', port=port, debug=debug)

