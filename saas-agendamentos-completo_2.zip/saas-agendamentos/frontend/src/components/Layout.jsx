import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Calendar,
  Users,
  Settings,
  LogOut,
  Menu,
  Home,
  User,
  Briefcase,
  Shield,
  Clock,
  Star
} from 'lucide-react'

const Layout = ({ children }) => {
  const { user, provider, logout, isAuthenticated, isProvider, isClient, isAdmin } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const getInitials = (name) => {
    return name
      ?.split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'U'
  }

  const getDashboardLink = () => {
    if (isAdmin) return '/admin'
    if (isProvider) return '/prestador'
    if (isClient) return '/cliente'
    return '/'
  }

  const getNavigationItems = () => {
    if (isAdmin) {
      return [
        { href: '/admin', label: 'Dashboard', icon: Home },
        { href: '/admin/usuarios', label: 'Usuários', icon: Users },
        { href: '/admin/prestadores', label: 'Prestadores', icon: Briefcase },
        { href: '/admin/agendamentos', label: 'Agendamentos', icon: Calendar },
        { href: '/admin/categorias', label: 'Categorias', icon: Star },
      ]
    }

    if (isProvider) {
      return [
        { href: '/prestador', label: 'Dashboard', icon: Home },
        { href: '/prestador/agendamentos', label: 'Agendamentos', icon: Calendar },
        { href: '/prestador/servicos', label: 'Serviços', icon: Briefcase },
        { href: '/prestador/perfil', label: 'Perfil', icon: User },
        { href: '/prestador/configuracoes', label: 'Configurações', icon: Settings },
      ]
    }

    if (isClient) {
      return [
        { href: '/cliente', label: 'Dashboard', icon: Home },
        { href: '/cliente/agendamentos', label: 'Meus Agendamentos', icon: Calendar },
        { href: '/cliente/perfil', label: 'Perfil', icon: User },
      ]
    }

    return []
  }

  const navigationItems = getNavigationItems()

  const NavItems = ({ mobile = false, onItemClick = () => {} }) => (
    <>
      {!isAuthenticated && (
        <>
          <Link
            to="/"
            className={`${mobile ? 'block px-3 py-2' : ''} text-gray-700 hover:text-blue-600 transition-colors`}
            onClick={onItemClick}
          >
            Início
          </Link>
          <Link
            to="/prestadores"
            className={`${mobile ? 'block px-3 py-2' : ''} text-gray-700 hover:text-blue-600 transition-colors`}
            onClick={onItemClick}
          >
            Prestadores
          </Link>
        </>
      )}
      
      {navigationItems.map((item) => {
        const Icon = item.icon
        const isActive = location.pathname === item.href
        
        return (
          <Link
            key={item.href}
            to={item.href}
            className={`${mobile ? 'flex items-center px-3 py-2 rounded-md' : 'flex items-center space-x-2'} 
              ${isActive 
                ? 'text-blue-600 bg-blue-50' 
                : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
              } transition-colors`}
            onClick={onItemClick}
          >
            <Icon className="h-4 w-4" />
            <span>{item.label}</span>
          </Link>
        )
      })}
    </>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <Calendar className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">
                  AgendaFácil
                </span>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <NavItems />
            </nav>

            {/* User Menu / Auth Buttons */}
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.avatar_url} alt={user.name} />
                        <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{user.name}</p>
                        <p className="text-xs leading-none text-muted-foreground">
                          {user.email}
                        </p>
                        {isProvider && provider && (
                          <p className="text-xs leading-none text-blue-600">
                            {provider.business_name}
                          </p>
                        )}
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to={getDashboardLink()} className="flex items-center">
                        <Home className="mr-2 h-4 w-4" />
                        <span>Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                    {isProvider && (
                      <DropdownMenuItem asChild>
                        <Link to={`/p/${provider?.slug}`} className="flex items-center">
                          <User className="mr-2 h-4 w-4" />
                          <span>Minha Página</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Sair</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="hidden md:flex items-center space-x-4">
                  <Link to="/login">
                    <Button variant="ghost">Entrar</Button>
                  </Link>
                  <Link to="/register">
                    <Button>Cadastrar</Button>
                  </Link>
                </div>
              )}

              {/* Mobile menu button */}
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                  <nav className="flex flex-col space-y-4">
                    <div className="flex items-center space-x-2 pb-4 border-b">
                      <Calendar className="h-6 w-6 text-blue-600" />
                      <span className="text-lg font-bold">AgendaFácil</span>
                    </div>
                    
                    <NavItems mobile onItemClick={() => setMobileMenuOpen(false)} />
                    
                    {!isAuthenticated && (
                      <div className="pt-4 border-t space-y-2">
                        <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                          <Button variant="ghost" className="w-full justify-start">
                            Entrar
                          </Button>
                        </Link>
                        <Link to="/register" onClick={() => setMobileMenuOpen(false)}>
                          <Button className="w-full">Cadastrar</Button>
                        </Link>
                      </div>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Calendar className="h-6 w-6 text-blue-600" />
                <span className="text-lg font-bold text-gray-900">AgendaFácil</span>
              </div>
              <p className="text-gray-600 text-sm">
                Sistema completo de agendamento online para prestadores de serviços.
                Simplifique sua agenda e melhore a experiência dos seus clientes.
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-900 mb-4">Para Prestadores</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link to="/register" className="hover:text-blue-600">Criar Conta</Link></li>
                <li><Link to="/prestadores" className="hover:text-blue-600">Ver Prestadores</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-900 mb-4">Suporte</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="mailto:suporte@agendafacil.com" className="hover:text-blue-600">Contato</a></li>
                <li><a href="https://wa.me/5511999999999" className="hover:text-blue-600">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t mt-8 pt-8 text-center text-sm text-gray-600">
            <p>&copy; 2024 AgendaFácil. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default Layout

