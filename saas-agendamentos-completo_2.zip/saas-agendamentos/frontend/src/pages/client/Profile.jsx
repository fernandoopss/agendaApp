import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const ProfilePage = () => (
  <div className="max-w-7xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold mb-8">Profile</h1>
    <Card>
      <CardHeader>
        <CardTitle>Em Desenvolvimento</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Página Profile em desenvolvimento.</p>
      </CardContent>
    </Card>
  </div>
)

export default ProfilePage
