import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const DashboardPage = () => (
  <div className="max-w-7xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
    <Card>
      <CardHeader>
        <CardTitle>Em Desenvolvimento</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Página Dashboard em desenvolvimento.</p>
      </CardContent>
    </Card>
  </div>
)

export default DashboardPage
