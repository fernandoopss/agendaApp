import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Calendar,
  Clock,
  MapPin,
  Star,
  Users,
  Smartphone,
  Shield,
  Zap,
  Search,
  ArrowRight,
  CheckCircle
} from 'lucide-react'
import { categoriesAPI, providersAPI } from '../lib/api'

const HomePage = () => {
  const [categories, setCategories] = useState([])
  const [featuredProviders, setFeaturedProviders] = useState([])
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const [categoriesResponse, providersResponse] = await Promise.all([
          categoriesAPI.listWithProviders(),
          providersAPI.list({ per_page: 6, sort: 'newest' })
        ])
        
        setCategories(categoriesResponse.data.categories)
        setFeaturedProviders(providersResponse.data.providers)
      } catch (error) {
        console.error('Erro ao carregar dados:', error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/prestadores?search=${encodeURIComponent(searchQuery.trim())}`
    }
  }

  const features = [
    {
      icon: Calendar,
      title: 'Agendamento Online',
      description: 'Permita que seus clientes agendem serviços 24/7 através da sua página personalizada'
    },
    {
      icon: Smartphone,
      title: 'Totalmente Responsivo',
      description: 'Funciona perfeitamente em celulares, tablets e computadores'
    },
    {
      icon: Shield,
      title: 'Seguro e Confiável',
      description: 'Seus dados e dos seus clientes estão protegidos com criptografia avançada'
    },
    {
      icon: Zap,
      title: 'Rápido e Fácil',
      description: 'Configure sua agenda em minutos e comece a receber agendamentos imediatamente'
    }
  ]

  const benefits = [
    'Página personalizada para seu negócio',
    'Gestão completa de agendamentos',
    'Notificações automáticas por email',
    'Relatórios e estatísticas',
    'Suporte técnico especializado',
    'Sem taxa de setup ou mensalidade'
  ]

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Simplifique seus
              <span className="block text-blue-200">Agendamentos</span>
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
              Crie sua página de agendamento online em minutos e ofereça uma experiência 
              profissional para seus clientes
            </p>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <form onSubmit={handleSearch} className="flex gap-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    type="text"
                    placeholder="Buscar prestadores de serviços..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 text-gray-900"
                  />
                </div>
                <Button type="submit" size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  Buscar
                </Button>
              </form>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  Criar Minha Página Grátis
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/prestadores">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  Ver Prestadores
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      {categories.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Categorias Populares
            </h2>
            <p className="text-lg text-gray-600">
              Encontre prestadores de serviços em diversas áreas
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/prestadores?category_id=${category.id}`}
                className="group"
              >
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div 
                      className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-2xl font-bold"
                      style={{ backgroundColor: category.color }}
                    >
                      {category.icon || category.name[0]}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-blue-600">
                      {category.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {category.providers_count} prestadores
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured Providers */}
      {featuredProviders.length > 0 && (
        <section className="bg-gray-100 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Prestadores em Destaque
              </h2>
              <p className="text-lg text-gray-600">
                Conheça alguns dos nossos prestadores mais bem avaliados
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProviders.map((provider) => (
                <Link key={provider.id} to={`/p/${provider.slug}`}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                          {provider.business_name[0]}
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{provider.business_name}</CardTitle>
                          <CardDescription className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {provider.city}, {provider.state}
                          </CardDescription>
                        </div>
                        {provider.is_verified && (
                          <Badge variant="secondary" className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Verificado
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {provider.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {provider.categories.slice(0, 3).map((category) => (
                          <Badge key={category.id} variant="outline">
                            {category.name}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Link to="/prestadores">
                <Button variant="outline" size="lg">
                  Ver Todos os Prestadores
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Por que escolher o AgendaFácil?
          </h2>
          <p className="text-lg text-gray-600">
            Tudo que você precisa para gerenciar seus agendamentos de forma profissional
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            )
          })}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-blue-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Tudo incluído no plano gratuito
              </h2>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8">
                <Link to="/register">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                    Começar Agora - É Grátis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white rounded-lg shadow-xl p-8">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Agendamentos Hoje</h3>
                    <Badge className="bg-green-100 text-green-800">+12%</Badge>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <Clock className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">09:00 - Corte de Cabelo</p>
                        <p className="text-sm text-gray-600">João Silva</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <Clock className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">14:30 - Manicure</p>
                        <p className="text-sm text-gray-600">Maria Santos</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <Clock className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">16:00 - Massagem</p>
                        <p className="text-sm text-gray-600">Ana Costa</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-900 text-white py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-4">
            Pronto para revolucionar seus agendamentos?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Junte-se a milhares de prestadores que já usam o AgendaFácil
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Criar Conta Gratuita
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/prestadores">
              <Button size="lg" variant="outline" className="border-gray-600 text-white hover:bg-gray-800">
                Explorar Prestadores
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

