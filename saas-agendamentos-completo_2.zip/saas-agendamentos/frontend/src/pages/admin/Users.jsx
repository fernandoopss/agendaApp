import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const UsersPage = () => (
  <div className="max-w-7xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold mb-8">Users</h1>
    <Card>
      <CardHeader>
        <CardTitle>Em Desenvolvimento</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Página Users em desenvolvimento.</p>
      </CardContent>
    </Card>
  </div>
)

export default UsersPage
