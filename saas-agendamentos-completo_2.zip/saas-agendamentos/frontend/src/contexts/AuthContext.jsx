import { createContext, useContext, useState, useEffect } from 'react'
import { api } from '../lib/api'

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [provider, setProvider] = useState(null)
  const [loading, setLoading] = useState(true)
  const [token, setToken] = useState(localStorage.getItem('token'))

  // Configurar token no cabeçalho da API
  useEffect(() => {
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
    } else {
      delete api.defaults.headers.common['Authorization']
    }
  }, [token])

  // Verificar usuário logado ao carregar a aplicação
  useEffect(() => {
    const checkAuth = async () => {
      if (token) {
        try {
          const response = await api.get('/auth/me')
          setUser(response.data.user)
          if (response.data.provider) {
            setProvider(response.data.provider)
          }
        } catch (error) {
          console.error('Erro ao verificar autenticação:', error)
          logout()
        }
      }
      setLoading(false)
    }

    checkAuth()
  }, [token])

  const login = async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password })
      const { user, provider, access_token, refresh_token } = response.data

      setUser(user)
      if (provider) {
        setProvider(provider)
      }
      setToken(access_token)
      
      localStorage.setItem('token', access_token)
      localStorage.setItem('refreshToken', refresh_token)

      return { success: true, user, provider }
    } catch (error) {
      console.error('Erro no login:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || 'Erro ao fazer login' 
      }
    }
  }

  const register = async (userData) => {
    try {
      const response = await api.post('/auth/register', userData)
      const { user, provider, access_token, refresh_token } = response.data

      setUser(user)
      if (provider) {
        setProvider(provider)
      }
      setToken(access_token)
      
      localStorage.setItem('token', access_token)
      localStorage.setItem('refreshToken', refresh_token)

      return { success: true, user, provider }
    } catch (error) {
      console.error('Erro no registro:', error)
      return { 
        success: false, 
        message: error.response?.data?.message || 'Erro ao criar conta' 
      }
    }
  }

  const logout = () => {
    setUser(null)
    setProvider(null)
    setToken(null)
    localStorage.removeItem('token')
    localStorage.removeItem('refreshToken')
    
    // Fazer logout no servidor
    api.post('/auth/logout').catch(() => {
      // Ignorar erros de logout
    })
  }

  const updateUser = (userData) => {
    setUser(prev => ({ ...prev, ...userData }))
  }

  const updateProvider = (providerData) => {
    setProvider(prev => ({ ...prev, ...providerData }))
  }

  const refreshToken = async () => {
    try {
      const refreshTokenValue = localStorage.getItem('refreshToken')
      if (!refreshTokenValue) {
        throw new Error('Refresh token não encontrado')
      }

      const response = await api.post('/auth/refresh', {}, {
        headers: {
          'Authorization': `Bearer ${refreshTokenValue}`
        }
      })

      const { access_token } = response.data
      setToken(access_token)
      localStorage.setItem('token', access_token)

      return access_token
    } catch (error) {
      console.error('Erro ao renovar token:', error)
      logout()
      throw error
    }
  }

  const isAuthenticated = !!user
  const isProvider = user?.role === 'provider'
  const isClient = user?.role === 'client'
  const isAdmin = user?.role === 'admin'

  const value = {
    user,
    provider,
    loading,
    token,
    isAuthenticated,
    isProvider,
    isClient,
    isAdmin,
    login,
    register,
    logout,
    updateUser,
    updateProvider,
    refreshToken
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

