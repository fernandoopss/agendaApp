import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import { Toaster } from '@/components/ui/toaster'

// Páginas públicas
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import ProvidersPage from './pages/ProvidersPage'
import ProviderPublicPage from './pages/ProviderPublicPage'
import BookingPage from './pages/BookingPage'

// Páginas do cliente
import ClientDashboard from './pages/client/Dashboard'
import ClientAppointments from './pages/client/Appointments'
import ClientProfile from './pages/client/Profile'

// Páginas do prestador
import ProviderDashboard from './pages/provider/Dashboard'
import ProviderAppointments from './pages/provider/Appointments'
import ProviderServices from './pages/provider/Services'
import ProviderProfile from './pages/provider/Profile'
import ProviderSettings from './pages/provider/Settings'

// Páginas do admin
import AdminDashboard from './pages/admin/Dashboard'
import AdminUsers from './pages/admin/Users'
import AdminProviders from './pages/admin/Providers'
import AdminAppointments from './pages/admin/Appointments'
import AdminCategories from './pages/admin/Categories'

// Componentes de proteção
import ProtectedRoute from './components/ProtectedRoute'
import Layout from './components/Layout'

import './App.css'

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            {/* Rotas públicas */}
            <Route path="/" element={<Layout><HomePage /></Layout>} />
            <Route path="/login" element={<Layout><LoginPage /></Layout>} />
            <Route path="/register" element={<Layout><RegisterPage /></Layout>} />
            <Route path="/prestadores" element={<Layout><ProvidersPage /></Layout>} />
            <Route path="/p/:slug" element={<Layout><ProviderPublicPage /></Layout>} />
            <Route path="/agendar/:slug/:serviceId" element={<Layout><BookingPage /></Layout>} />

            {/* Rotas do cliente */}
            <Route path="/cliente" element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout><ClientDashboard /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/cliente/agendamentos" element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout><ClientAppointments /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/cliente/perfil" element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout><ClientProfile /></Layout>
              </ProtectedRoute>
            } />

            {/* Rotas do prestador */}
            <Route path="/prestador" element={
              <ProtectedRoute allowedRoles={['provider']}>
                <Layout><ProviderDashboard /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/prestador/agendamentos" element={
              <ProtectedRoute allowedRoles={['provider']}>
                <Layout><ProviderAppointments /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/prestador/servicos" element={
              <ProtectedRoute allowedRoles={['provider']}>
                <Layout><ProviderServices /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/prestador/perfil" element={
              <ProtectedRoute allowedRoles={['provider']}>
                <Layout><ProviderProfile /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/prestador/configuracoes" element={
              <ProtectedRoute allowedRoles={['provider']}>
                <Layout><ProviderSettings /></Layout>
              </ProtectedRoute>
            } />

            {/* Rotas do admin */}
            <Route path="/admin" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout><AdminDashboard /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/admin/usuarios" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout><AdminUsers /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/admin/prestadores" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout><AdminProviders /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/admin/agendamentos" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout><AdminAppointments /></Layout>
              </ProtectedRoute>
            } />
            <Route path="/admin/categorias" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout><AdminCategories /></Layout>
              </ProtectedRoute>
            } />

            {/* Página 404 */}
            <Route path="*" element={
              <Layout>
                <div className="flex items-center justify-center min-h-[60vh]">
                  <div className="text-center">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">404</h1>
                    <p className="text-gray-600 mb-8">Página não encontrada</p>
                    <a href="/" className="text-blue-600 hover:text-blue-800">
                      Voltar ao início
                    </a>
                  </div>
                </div>
              </Layout>
            } />
          </Routes>
          <Toaster />
        </div>
      </Router>
    </AuthProvider>
  )
}

export default App

